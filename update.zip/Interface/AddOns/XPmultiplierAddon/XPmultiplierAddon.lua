XPCurrentMultiplier="1" --начальный множитель опыта

local XPMultiplierFrame = CreateFrame("Button", "XPMultiplierFrameButton", UIParent) --центральная кнопка
XPMultiplierFrame:SetSize(40,40)
XPMultiplierFrame:SetMovable(true)
XPMultiplierFrame:EnableMouse(true)
XPMultiplierFrame:RegisterForDrag("LeftButton")
XPMultiplierFrame:SetScript("OnDragStart", XPMultiplierFrame.StartMoving)
XPMultiplierFrame:SetScript("OnDragStop", XPMultiplierFrame.StopMovingOrSizing)
XPMultiplierFrame:SetPoint("TOP",0,-10)
XPMultiplierFrame.border = XPMultiplierFrame:CreateTexture(nil, "ARTWORK")
XPMultiplierFrame.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
XPMultiplierFrame.border:SetTexCoord(0,0.6,0,0.6);
XPMultiplierFrame.border:SetAllPoints(XPMultiplierFrame);
XPMultiplierFrame.text = XPMultiplierFrame:CreateFontString(nil, "ARTWORK","GameFontNormal")
XPMultiplierFrame.text:Show()
XPMultiplierFrame.text:SetText("x"..XPCurrentMultiplier)
XPMultiplierFrame.text:SetTextColor(1,0.9,0,1)
XPMultiplierFrame.text:SetFont("Fonts\\FRIZQT__.TTF",15)
XPMultiplierFrame.text:SetAllPoints(XPMultiplierFrame)
XPMultiplierFrame:SetScript("OnEnter", function()
	GameTooltip:SetOwner(XPMultiplierFrame, "ANCHOR_BOTTOMRIGHT")
	GameTooltip:SetText("Рейт опыта")
    GameTooltip:Show()
  end)
XPMultiplierFrame:SetScript("OnLeave", function()
    GameTooltip:Hide()
  end)
XPMultiplierFrame:SetScript("OnClick", function()			--показать множитель
	local text=ChatFrame1EditBox:GetText()
	ChatFrame1EditBox:SetText(".XP View")
	ChatEdit_SendText(ChatFrame1EditBox)
	ChatFrame1EditBox:SetText(text)
	CorrectXPMultiplierPosition()
end)
--
local XPMultiplierFrameBTRight= CreateFrame("Button", nil, XPMultiplierFrame,"SecureHandlerClickTemplate")
XPMultiplierFrameBTRight:SetSize(32,32)
XPMultiplierFrameBTRight:RegisterForClicks("AnyUP");
XPMultiplierFrameBTRight:SetScript("OnClick", function()	--увеличить множитель
	local text=ChatFrame1EditBox:GetText()
	ChatFrame1EditBox:SetText(".XP inc")
	ChatEdit_SendText(ChatFrame1EditBox)
	ChatFrame1EditBox:SetText(text)
	CorrectXPMultiplierPosition()
end)
XPMultiplierFrameBTRight:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
XPMultiplierFrameBTRight:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Down")
XPMultiplierFrameBTRight:SetPoint("RIGHT",XPMultiplierFrameButton,24,0)
--
local XPMultiplierFrameBTLeft= CreateFrame("Button", nil, XPMultiplierFrame,"SecureHandlerClickTemplate")
XPMultiplierFrameBTLeft:SetSize(32,32)
XPMultiplierFrameBTLeft:RegisterForClicks("AnyUP");
XPMultiplierFrameBTLeft:SetScript("OnClick", function() 	--уменьшить множитель
	local text=ChatFrame1EditBox:GetText()
	ChatFrame1EditBox:SetText(".XP dec")
	ChatEdit_SendText(ChatFrame1EditBox)
	ChatFrame1EditBox:SetText(text)
	CorrectXPMultiplierPosition()
end)
XPMultiplierFrameBTLeft:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up")
XPMultiplierFrameBTLeft:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Down")
XPMultiplierFrameBTLeft:SetPoint("RIGHT",XPMultiplierFrameButton,-32,0)
--
function CorrectXPMultiplierPosition()
	XPMultiplierFrame.text:SetText("x"..XPCurrentMultiplier)
	if (string.len(XPMultiplierFrame.text:GetText())) >2 then
		XPMultiplierFrame:SetWidth(54)
		XPMultiplierFrameBTLeft:SetPoint("RIGHT",XPMultiplierFrameButton,-44,0)
	else
		XPMultiplierFrame:SetWidth(40)
		XPMultiplierFrameBTLeft:SetPoint("RIGHT",XPMultiplierFrameButton,-32,0)
	end
end
--
local onloadframe
onloadframe=CreateFrame("FRAME")
onloadframe:RegisterEvent("ADDON_LOADED");
onloadframe:SetScript("OnEvent",function(self, event, addonName)
	if addonName=="XPmultiplierAddon" then
		CorrectXPMultiplierPosition()
	end
end)
--
local keywords = "сообщение с множителем+(%d+)"
local multipliersearch = CreateFrame("Frame") --поиск множителя
multipliersearch:RegisterEvent("CHAT_MSG_SYSTEM")
multipliersearch:SetScript("OnEvent", function(self, event, ...)
	self[event](self, ...)
end)
function multipliersearch:CHAT_MSG_SYSTEM(msg, author, ...)
    local s, e, num = msg:find("сообщение с множителем+(%d+)")
    if s then
            if msg:find(keywords) then
			XPCurrentMultiplier=tostring(num)
			CorrectXPMultiplierPosition()
        end
    end
end