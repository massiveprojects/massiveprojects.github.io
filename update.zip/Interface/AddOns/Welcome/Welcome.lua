---@diagnostic disable: lowercase-global, undefined-global
-- Author      : deny
-- Create Date : 05.03.2023 16:06:52

ListenFrame = CreateFrame("Frame", "ListenFrame", UIParent);
ListenFrame:RegisterEvent("CHAT_MSG_SYSTEM");


local function ListenFrame_OnEvent(self, event, msg, ...)
	if event == "CHAT_MSG_SYSTEM" and msg == "Добро пожаловать. (Welcome.)" then
		WelcomeFrame:Show();
		WelcomeFrame:SetActive();
		--return false, msg, ...
		chatSAY("ОУ");
	end
	
	--return true, msg, ...
end
ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", ListenFrame_OnEvent);

function chatSAY(text)
	SendChatMessage(text, "SAY", nil, nil);
end

function classic_button_OnClick()
	WelcomeFrame:Hide();
end

function new_button_OnClick()
	chatSAY(".newway");
	WelcomeFrame:Hide();
end