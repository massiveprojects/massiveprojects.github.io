---@diagnostic disable: lowercase-global, undefined-global
-- Author      : Massive Projects
-- Create Date : 05.03.2023 16:06:52

function chatSAY(text)
	SendChatMessage(text, "SAY", nil, nil);
end