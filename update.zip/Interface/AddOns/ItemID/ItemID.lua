function addline_itemid()
	itemName,itemLink = ItemRefTooltip:GetItem()
	if itemLink ~= nil then	
		local aaa, is1, a2, a3, a4, a5, a6, is2, is3,a7 = strsplit(":",string.match(itemLink, "item[%-?%d:]+"))
		ItemRefTooltip:AddDoubleLine("ItemID:",is1);
		ItemRefTooltip:Show();
	end
end


function addline_gametip()
	itemName,itemLink = GameTooltip:GetItem()
	if itemLink ~= nil then
		stats = GetItemStats(itemLink)
		local start, id, en, g1, g2, g3, g4 = strsplit(":", itemLink)

		itemName1, itemLink1, itemRarity1, itemLevel1, itemMinLevel1, itemType1,
		itemSubType1, itemStackCount1, itemEquipLoc1, itemTexture1, itemSellPrice1 =
		GetItemInfo(itemLink)
		
		GameTooltip:AddDoubleLine("ItemClass:",itemType1);
		GameTooltip:AddDoubleLine("ItemSubclass:",itemSubType1);
		GameTooltip:AddDoubleLine("ItemID:",id);
	end
end

ItemRefTooltip:SetScript("OnShow", addline_itemid)
GameTooltip:SetScript("OnShow",addline_gametip)