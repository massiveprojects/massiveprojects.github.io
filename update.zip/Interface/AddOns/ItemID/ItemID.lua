function chck(ench)
	if GetLocale() == "ruRU" then
		if tonumber(ench) > 47000000 then
			return "+"..(tonumber(ench) - 47000000).." к проникающей способности заклинаний";
		end
		if tonumber(ench) > 45000000 then
			return "+"..(tonumber(ench) - 45000000).." к силе заклинаний";
		end
		if tonumber(ench) > 44000000 then
			return "+"..(tonumber(ench) - 44000000).." к пробиванию брони";
		end
		if tonumber(ench) > 38000000 then
			return "+"..(tonumber(ench) - 38000000).." к силе атаки";
		end
		if tonumber(ench) > 37000000 then
			return "+"..(tonumber(ench) - 37000000).." к мастерству";
		end
		if tonumber(ench) > 36000000 then
			return "+"..(tonumber(ench) - 36000000).." к рейтингу скорости";
		end
		if tonumber(ench) > 35000000 then
			return "+"..(tonumber(ench) - 35000000).." к устойчивости";
		end
		if tonumber(ench) > 32000000 then
			return "+"..(tonumber(ench) - 32000000).." к рейтингу крита";
		end
		if tonumber(ench) > 31000000 then
			return "+"..(tonumber(ench) - 31000000).." к рейтингу меткости";
		end
		if tonumber(ench) > 15000000 then
			return "+"..(tonumber(ench) - 15000000).." к рейтингу блокирования";
		end
		if tonumber(ench) > 14000000 then
			return "+"..(tonumber(ench) - 14000000).." к рейтингу парирования";
		end
		if tonumber(ench) > 13000000 then
			return "+"..(tonumber(ench) - 13000000).." к рейтингу уклонения";
		end
		if tonumber(ench) > 12000000 then
			return "+"..(tonumber(ench) - 12000000).." к защите";
		end
		if tonumber(ench) > 8000000 then
			return "+"..(tonumber(ench) - 8000000).." к броне";
		end
		if tonumber(ench) > 7000000 then
			return "+"..(tonumber(ench) - 7000000).." к выносливости";
		end
		if tonumber(ench) > 6000000 then
			return "+"..(tonumber(ench) - 6000000).." к духу";
		end
		if tonumber(ench) > 5000000 then
			return "+"..(tonumber(ench) - 5000000).." к интелекту";
		end
		if tonumber(ench) > 4000000 then
			return "+"..(tonumber(ench) - 4000000).." к силе";
		end
		if tonumber(ench) > 3000000 then
			return "+"..(tonumber(ench) - 3000000).." к ловкости";
		end
		return "Ошибка";
	else
		if tonumber(ench) > 47000000 then
			return "+"..(tonumber(ench) - 47000000).." Spell penetration";
		end
		if tonumber(ench) > 45000000 then
			return "+"..(tonumber(ench) - 45000000).." Spell Power";
		end
		if tonumber(ench) > 44000000 then
			return "+"..(tonumber(ench) - 44000000).." Armor penetration";
		end
		if tonumber(ench) > 38000000 then
			return "+"..(tonumber(ench) - 38000000).." Attack Power";
		end
		if tonumber(ench) > 37000000 then
			return "+"..(tonumber(ench) - 37000000).." Expertise";
		end
		if tonumber(ench) > 36000000 then
			return "+"..(tonumber(ench) - 36000000).." Haste Rating";
		end
		if tonumber(ench) > 35000000 then
			return "+"..(tonumber(ench) - 35000000).." Resilence";
		end
		if tonumber(ench) > 32000000 then
			return "+"..(tonumber(ench) - 32000000).." Crit Rating";
		end
		if tonumber(ench) > 31000000 then
			return "+"..(tonumber(ench) - 31000000).." Hit Rating";
		end
		if tonumber(ench) > 15000000 then
			return "+"..(tonumber(ench) - 15000000).." Block Rating";
		end
		if tonumber(ench) > 14000000 then
			return "+"..(tonumber(ench) - 14000000).." Parry Rating";
		end
		if tonumber(ench) > 13000000 then
			return "+"..(tonumber(ench) - 13000000).." Dodge Rating";
		end
		if tonumber(ench) > 12000000 then
			return "+"..(tonumber(ench) - 12000000).." Defence";
		end
		if tonumber(ench) > 8000000 then
			return "+"..(tonumber(ench) - 8000000).." Armor";
		end
		if tonumber(ench) > 7000000 then
			return "+"..(tonumber(ench) - 7000000).." Stamina";
		end
		if tonumber(ench) > 6000000 then
			return "+"..(tonumber(ench) - 6000000).." Spirit";
		end
		if tonumber(ench) > 5000000 then
			return "+"..(tonumber(ench) - 5000000).." Intelligence";
		end
		if tonumber(ench) > 4000000 then
			return "+"..(tonumber(ench) - 4000000).." Stranght";
		end
		if tonumber(ench) > 3000000 then
			return "+"..(tonumber(ench) - 3000000).." Agility";
		end
		return "Error";
	end

end

function addline_itemid()
	itemName,itemLink = ItemRefTooltip:GetItem()
	if itemLink ~= nil then
		local aaa, id, g1, g2, g3, bbb, fake, s4, s5, render = strsplit(":",string.match(itemLink, "item[%-?%d:]+"))
		local lastPosition = 0
		--3, 4, 5, 6, 7, 12, 13, 14, 15, 31, 32, 35, 36, 37, 38, 44, 45, 47
		if s4 ~= "0" then
			ItemRefTooltip:AddLine("|cFFFFFFFF"..chck(s4))
		end
		if s5 ~= "0" then
			ItemRefTooltip:AddLine("|cFFFFFFFF"..chck(s5))
		end
		ItemRefTooltip:AddDoubleLine("ItemID:",id)
		ItemRefTooltip:Show()
	end
end



function addline_gametip()
	itemName,itemLink = GameTooltip:GetItem()
	if itemLink ~= nil then
		stats = GetItemStats(itemLink)
		local start, id, en, g1, g2, g3, g4 = strsplit(":", itemLink)

		itemName1, itemLink1, itemRarity1, itemLevel1, itemMinLevel1, itemType1,
		itemSubType1, itemStackCount1, itemEquipLoc1, itemTexture1, itemSellPrice1 =
		GetItemInfo(itemLink)
		
		GameTooltip:AddDoubleLine("ItemClass:",itemType1)
		if itemType1 ~= "Деньги" and itemType1 ~= "Money" then
			GameTooltip:AddDoubleLine("ItemSubclass:",itemSubType1)
		end
		GameTooltip:AddDoubleLine("ItemID:",id)
	end
end

ItemRefTooltip:SetScript("OnShow", addline_itemid)
GameTooltip:SetScript("OnShow",addline_gametip)